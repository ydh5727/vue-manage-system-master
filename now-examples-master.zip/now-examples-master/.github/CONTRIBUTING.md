# Contributing

1. Add a new folder with the name of the project
2. Create the minimum files required to build the project
3. Keep the example Docker image as small as possible
4. Add a README.md file to the project based on this [template](.github/EXAMPLE_README_TEMPLATE.md)
5. Add the example to the main README.md
