module.exports = (req, res) => {
  res.end(new Date().toString());
};
