<template>
  <h1>Static Nuxt Example on Now 2.0</h1>
</template>

<style>
h1 {
  font-size: 48px;
}
</style>
