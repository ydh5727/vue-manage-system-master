# Serverless Rendering: A Case Study

An implementation of SSR with 5 UI tools:

- Vue
- lit-html
- React
- Preact
- vhtml
