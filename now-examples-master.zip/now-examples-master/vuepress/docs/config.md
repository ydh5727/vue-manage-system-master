# Example Config Route
