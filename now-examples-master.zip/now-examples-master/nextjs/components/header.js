export default () => (
  <header>
    <h1>Next.js Example on Now 2.0</h1>
  </header>
);