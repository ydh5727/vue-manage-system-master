export default () => (
  <header>
    <h1>Static Next.js Example on Now 2.0</h1>
  </header>
)
