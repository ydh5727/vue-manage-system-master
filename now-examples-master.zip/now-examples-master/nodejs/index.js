module.exports = (req, res) => {
  res.end(`Hello from Node.js on Now 2.0!`);
};