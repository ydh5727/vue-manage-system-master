import LoginForm from '../components/login-form'

export default () => (
  <div>
    <LoginForm />
  </div>
)
