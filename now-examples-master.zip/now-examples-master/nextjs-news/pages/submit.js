import React from 'react'
import LoginForm from '../components/login-form'

export default () => (
  <div>
    <p>You have to be logged in to submit</p>
    <LoginForm />
  </div>
)
